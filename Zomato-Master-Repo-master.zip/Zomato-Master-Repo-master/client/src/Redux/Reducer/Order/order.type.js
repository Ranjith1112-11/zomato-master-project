export const CREATE_ORDER = "CREATE_ORDER";
export const ORDER_PLACED = "ORDER_PLACED";
