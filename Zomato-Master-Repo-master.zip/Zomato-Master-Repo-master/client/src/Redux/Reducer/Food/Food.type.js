export const GET_FOOD_LIST = "GET_FOOD_LIST";
export const GET_FOOD = "GET_FOOD";
