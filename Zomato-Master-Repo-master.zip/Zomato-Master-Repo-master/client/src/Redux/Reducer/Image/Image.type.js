export const GET_IMAGE = "GET_IMAGE";
